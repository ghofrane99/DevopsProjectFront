export class Reglement {
  idReglement: any;
  montantPaye: any;
  montantRestant: any;
  payee: any;
  dateReglement: any;
}
