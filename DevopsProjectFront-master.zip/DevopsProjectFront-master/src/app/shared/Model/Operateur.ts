export class Operateur {
    idOperateur:any;
	  nom:any;
	  prenom:any;
	  password:any;
}
