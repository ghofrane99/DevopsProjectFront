export class SecteurActivite {

    idSecteurActivite:any;
    codeSecteurActivite : any;
    libelleSecteurActivite : any;
    
}
