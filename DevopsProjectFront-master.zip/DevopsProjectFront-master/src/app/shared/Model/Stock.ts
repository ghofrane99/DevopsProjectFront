export class Stock {
    idStock:any;
    libelleStock : any;
    qte : any;
    qteMin : any;

}
